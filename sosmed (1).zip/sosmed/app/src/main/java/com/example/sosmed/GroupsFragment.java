package com.example.sosmed;

import androidx.fragment.app.Fragment;

public class GroupsFragment extends Fragment {
}
