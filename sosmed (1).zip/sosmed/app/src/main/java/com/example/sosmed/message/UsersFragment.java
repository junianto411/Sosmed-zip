package com.example.sosmed.message;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.example.sosmed.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import java.util.ArrayList;
import java.util.List;

public class UsersFragment extends Fragment {

    private ListView userList;
    private UserAdapter userAdapter;
    private List<User> userListItems;

    private FirebaseFirestore firestore;
    private DatabaseReference chatsDatabase;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_user, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        userList = view.findViewById(R.id.user_list);

        firestore = FirebaseFirestore.getInstance();
        chatsDatabase = FirebaseDatabase.getInstance().getReference().child("chats");

        userListItems = new ArrayList<>();
        userAdapter = new UserAdapter(getContext(), userListItems);
        userList.setAdapter(userAdapter);

        userList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                User selectedUser = userListItems.get(position);
                startChat(selectedUser);
            }
        });

        loadUsers();
    }

    private void loadUsers() {
        firestore.collection("users").get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                userListItems.clear();
                for (QueryDocumentSnapshot document : task.getResult()) {
                    User user = document.toObject(User.class);
                    userListItems.add(user);
                }
                userAdapter.notifyDataSetChanged();
            } else {
                // Handle error
            }
        });
    }

    private void startChat(User user) {
        // Get current user's ID
        String currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        String userId = user.getId(); // Assuming userId is stored as id

        // Create a unique chat ID
        String chatId = chatsDatabase.push().getKey();

        if (chatId != null) {
            Chat chat = new Chat(currentUserId, userId);
            chatsDatabase.child(chatId).setValue(chat);
            Intent intent = new Intent(getContext(), ChatActivity.class);
            intent.putExtra("chatId", chatId);
            intent.putExtra("userId", userId);
            startActivity(intent);
        }
    }
}
